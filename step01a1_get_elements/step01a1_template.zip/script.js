// まずはブラウザのコンソールで実行してみよう！
// F12キーを押してコンソールを開いて、以下のコードを試してください：
//
// const button = document.querySelector('#btn-rock');
// console.log(button);
//
// 動作を確認したら、ここに書いてみましょう
